package com.bouali.banking.models;

/**
 * @author Ali Bouali
 * @since 12.09.22
 */

public enum TransactionType {

  TRANSFERT,
  DEPOSIT

}
