package com.bouali.banking.services;

import com.bouali.banking.dto.AccountDto;

/**
 * @author Ali Bouali
 */
public interface AccountService extends AbstractService<AccountDto> {

}
