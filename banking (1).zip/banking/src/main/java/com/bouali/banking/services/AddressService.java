package com.bouali.banking.services;

import com.bouali.banking.dto.AddressDto;

/**
 * @author Ali Bouali
 */
public interface AddressService extends AbstractService<AddressDto> {

}
